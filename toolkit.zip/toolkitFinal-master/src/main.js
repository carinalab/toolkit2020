/* eslint-disable no-new */
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
// import '@fortawesome/fontawesome-free/css/all.css'
import Vue from 'vue'
import App from './App'
import {router} from './router'
import Vuetify from 'vuetify'
import store from './store/index'
import 'vuetify/dist/vuetify.min.css'
import icon from '@/assets/noun_brainstorming.svg'
import VueFire from 'vuefire'
import firebase from 'firebase/app'
import 'firebase/storage'
import 'firebase/auth'
import 'firebase/firestore'
import GSignInButton from 'vue-google-signin-button'

const tema = {
  icon: {
    ej: icon
  },
  theme: {
    primary: '#CA0E67',
    secondary: '#FFFD38',
    accent: '#35CCCC',
    error: '#FF7B00',
    info: '#60DD99',
    success: '#FFA726',
    warning: '#7269DB',
    black: '#000000',
    white: '#F1EFEB',
    disable: '#595F62'
  }
}

Vue.use(Vuetify, tema)
Vue.use(VueFire)
Vue.use(GSignInButton)

const config = {
  apiKey: "AIzaSyDhvfRI-x5TPUrmQVmf5M-htzRRSYd2ou0",
  authDomain: "toolkit-2020-b41b2.firebaseapp.com",
  databaseURL: "https://toolkit-2020-b41b2.firebaseio.com",
  projectId: "toolkit-2020-b41b2",
  storageBucket: "toolkit-2020-b41b2.appspot.com",
  messagingSenderId: "450140708489",
  appId: "1:450140708489:web:176d9e1ee2054587abf058",
  measurementId: "G-2LR3636GF2"
}

const url = 'http://localhost:8080'

Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store: store,
  components: { App },
  template: '<App/>'
})
// 'http://172.19.0.56:3000'
const firebaseApp = firebase.initializeApp(config)
const db = firebaseApp.firestore()
const auth = firebaseApp.auth()
db.settings({timestampsInSnapshots: true})
const storage = firebase.storage()

export {db, auth, storage, url}
